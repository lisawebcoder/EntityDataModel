﻿
namespace FinalExam.GUI
{
    partial class FormCourseAssignment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxTeacher = new System.Windows.Forms.ComboBox();
            this.comboBoxCourse = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.maskedTextBoxAssignedDate = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonAssignCourse = new System.Windows.Forms.Button();
            this.buttonListCourses = new System.Windows.Forms.Button();
            this.buttonListTeacher = new System.Windows.Forms.Button();
            this.listViewTeacher = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewCourse = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.buttonBack = new System.Windows.Forms.Button();
            this.buttonSaveToXML = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select the Teacher";
            // 
            // comboBoxTeacher
            // 
            this.comboBoxTeacher.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTeacher.FormattingEnabled = true;
            this.comboBoxTeacher.Location = new System.Drawing.Point(50, 53);
            this.comboBoxTeacher.Name = "comboBoxTeacher";
            this.comboBoxTeacher.Size = new System.Drawing.Size(164, 21);
            this.comboBoxTeacher.TabIndex = 1;
            // 
            // comboBoxCourse
            // 
            this.comboBoxCourse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCourse.FormattingEnabled = true;
            this.comboBoxCourse.Location = new System.Drawing.Point(50, 132);
            this.comboBoxCourse.Name = "comboBoxCourse";
            this.comboBoxCourse.Size = new System.Drawing.Size(324, 21);
            this.comboBoxCourse.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Select the Course";
            // 
            // maskedTextBoxAssignedDate
            // 
            this.maskedTextBoxAssignedDate.Location = new System.Drawing.Point(47, 219);
            this.maskedTextBoxAssignedDate.Mask = "00/00/0000";
            this.maskedTextBoxAssignedDate.Name = "maskedTextBoxAssignedDate";
            this.maskedTextBoxAssignedDate.Size = new System.Drawing.Size(154, 20);
            this.maskedTextBoxAssignedDate.TabIndex = 4;
            this.maskedTextBoxAssignedDate.ValidatingType = typeof(System.DateTime);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(47, 188);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Assigned Date";
            // 
            // buttonAssignCourse
            // 
            this.buttonAssignCourse.Location = new System.Drawing.Point(47, 263);
            this.buttonAssignCourse.Name = "buttonAssignCourse";
            this.buttonAssignCourse.Size = new System.Drawing.Size(112, 36);
            this.buttonAssignCourse.TabIndex = 6;
            this.buttonAssignCourse.Text = "Assign Course";
            this.buttonAssignCourse.UseVisualStyleBackColor = true;
            this.buttonAssignCourse.Click += new System.EventHandler(this.buttonAssignCourse_Click);
            // 
            // buttonListCourses
            // 
            this.buttonListCourses.Location = new System.Drawing.Point(594, 11);
            this.buttonListCourses.Name = "buttonListCourses";
            this.buttonListCourses.Size = new System.Drawing.Size(112, 36);
            this.buttonListCourses.TabIndex = 7;
            this.buttonListCourses.Text = "List Courses";
            this.buttonListCourses.UseVisualStyleBackColor = true;
            this.buttonListCourses.Click += new System.EventHandler(this.buttonListCourses_Click);
            // 
            // buttonListTeacher
            // 
            this.buttonListTeacher.Location = new System.Drawing.Point(594, 176);
            this.buttonListTeacher.Name = "buttonListTeacher";
            this.buttonListTeacher.Size = new System.Drawing.Size(112, 36);
            this.buttonListTeacher.TabIndex = 8;
            this.buttonListTeacher.Text = "List Teachers";
            this.buttonListTeacher.UseVisualStyleBackColor = true;
            // 
            // listViewTeacher
            // 
            this.listViewTeacher.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listViewTeacher.GridLines = true;
            this.listViewTeacher.HideSelection = false;
            this.listViewTeacher.Location = new System.Drawing.Point(413, 249);
            this.listViewTeacher.Name = "listViewTeacher";
            this.listViewTeacher.Size = new System.Drawing.Size(509, 97);
            this.listViewTeacher.TabIndex = 9;
            this.listViewTeacher.UseCompatibleStateImageBehavior = false;
            this.listViewTeacher.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Teacher Number";
            this.columnHeader1.Width = 151;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "First Name";
            this.columnHeader2.Width = 156;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Last Name";
            this.columnHeader3.Width = 385;
            // 
            // listViewCourse
            // 
            this.listViewCourse.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.listViewCourse.HideSelection = false;
            this.listViewCourse.Location = new System.Drawing.Point(413, 56);
            this.listViewCourse.Name = "listViewCourse";
            this.listViewCourse.Size = new System.Drawing.Size(509, 97);
            this.listViewCourse.TabIndex = 10;
            this.listViewCourse.UseCompatibleStateImageBehavior = false;
            this.listViewCourse.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Course Number";
            this.columnHeader4.Width = 108;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Course Title";
            this.columnHeader5.Width = 252;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Total Hours";
            this.columnHeader6.Width = 385;
            // 
            // buttonBack
            // 
            this.buttonBack.Location = new System.Drawing.Point(810, 386);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(112, 36);
            this.buttonBack.TabIndex = 11;
            this.buttonBack.Text = "Back";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // buttonSaveToXML
            // 
            this.buttonSaveToXML.Location = new System.Drawing.Point(47, 321);
            this.buttonSaveToXML.Name = "buttonSaveToXML";
            this.buttonSaveToXML.Size = new System.Drawing.Size(112, 36);
            this.buttonSaveToXML.TabIndex = 12;
            this.buttonSaveToXML.Text = "Save to XML File";
            this.buttonSaveToXML.UseVisualStyleBackColor = true;
            this.buttonSaveToXML.Click += new System.EventHandler(this.buttonSaveToXML_Click);
            // 
            // FormCourseAssignment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(969, 452);
            this.Controls.Add(this.buttonSaveToXML);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.listViewCourse);
            this.Controls.Add(this.listViewTeacher);
            this.Controls.Add(this.buttonListTeacher);
            this.Controls.Add(this.buttonListCourses);
            this.Controls.Add(this.buttonAssignCourse);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.maskedTextBoxAssignedDate);
            this.Controls.Add(this.comboBoxCourse);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBoxTeacher);
            this.Controls.Add(this.label1);
            this.Name = "FormCourseAssignment";
            this.Text = "SMTI Teacher - Course Management Form";
            this.Load += new System.EventHandler(this.FormCourseAssignment_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxTeacher;
        private System.Windows.Forms.ComboBox comboBoxCourse;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxAssignedDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonAssignCourse;
        private System.Windows.Forms.Button buttonListCourses;
        private System.Windows.Forms.Button buttonListTeacher;
        private System.Windows.Forms.ListView listViewTeacher;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ListView listViewCourse;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Button buttonSaveToXML;
    }
}