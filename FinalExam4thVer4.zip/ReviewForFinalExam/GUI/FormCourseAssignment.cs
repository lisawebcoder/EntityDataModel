﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using System.Xml.Serialization; // XmlSerializer class; serialization/ deserialization
//using System.IO;
using FinalExam.Business;


namespace FinalExam.GUI
{
    public partial class FormCourseAssignment : Form
    {
        
        List<CourseAssignment> listCourseAssigned = new List<CourseAssignment>();
        static string filePath = Environment.CurrentDirectory + @"\CoursesAssigned.Xml";
        public FormCourseAssignment()
        {
            InitializeComponent();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormLogIn formLogIn = new FormLogIn();
            formLogIn.ShowDialog();
        }

        private void FormCourseAssignment_Load(object sender, EventArgs e)
        {
            
            List<Employee> listEmp = new List<Employee>();
            Employee emp = new Employee();
            listEmp = emp.GetListEmployee();
            
            foreach (var itemE in listEmp)
            {   
                if ((itemE.JobTitle.ToUpper() == "Teacher".ToUpper()))
                {
                    
                    comboBoxTeacher.Items.Add(itemE.EmployeeNumber + "," + itemE.FirstName + "," + itemE.LastName);

                }

            }

            List<Course> listCourse = new List<Course>();
            Course course = new Course();
            listCourse = course.GetAllCourses();
            foreach (var itemC in listCourse)
            {
                comboBoxCourse.Items.Add(itemC.CourseNumber + "," + itemC.CourseTitle + "," + itemC.TotalHour);
            }
        }

        private void buttonAssignCourse_Click(object sender, EventArgs e)
        {
            if (comboBoxTeacher.SelectedIndex==-1)
            {
                MessageBox.Show("Please select the teacher.","Teacher required");
                return;
            }

            if (comboBoxCourse.SelectedIndex == -1)
            {
                MessageBox.Show("Please select the course.", "Course required");
                return;
            }

            CourseAssignment ca = new CourseAssignment();
            string[] teacherFields = (comboBoxTeacher.Text).Split(',');
            int teacherId = Convert.ToInt32(teacherFields[0]);
            string[] courseFields = (comboBoxCourse.Text).Split(',');
            string courseId = courseFields[0];

            //Check duplicate course assignments
            List<CourseAssignment> listCA = ca.GetAllCoursesAssigned();
            foreach (var itemCA in listCA)
            {
                if ((itemCA.CourseNumber == courseId) && (itemCA.EmployeeNumber==teacherId))
                {
                    MessageBox.Show("This course has been assigned to this teacher.",
                                     "Duplicate Course Assignment",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return;
                }

            }

            //Check the number of courses assigned //cannot exceed 3 courses
            List<Course> listC = ca.GetCourseList(teacherId);
            if (listC.Count == 3)
            {
                MessageBox.Show("This teacher has been assigned 3 courses", "Number of Courses");
                return;

            }
            ca.EmployeeNumber = teacherId;
            ca.CourseNumber = courseId;
            ca.AssignedDate = DateTime.Parse (maskedTextBoxAssignedDate.Text);
            listCourseAssigned.Add(ca);
            MessageBox.Show("The course has been added to the list","List of Courses");

        }

        private void buttonSaveToXML_Click(object sender, EventArgs e)
        {
            CourseAssignment ca = new CourseAssignment();
            ca.SaveCoursesAssigned(listCourseAssigned);

        }

        private void buttonListCourses_Click(object sender, EventArgs e)
        {
            if (comboBoxTeacher.SelectedIndex == -1)
            {
                MessageBox.Show("Please select the teacher.", "Teacher required");
                return;
            }

            CourseAssignment ca = new CourseAssignment();
            string[] teacherFields = (comboBoxTeacher.Text).Split(',');
            int teacherId = Convert.ToInt32(teacherFields[0]);
            List<Course> listC = ca.GetCourseList(teacherId);
            listViewCourse.Items.Clear();
            foreach (var item in listC)
            {
                ListViewItem itemC = new ListViewItem(item.CourseNumber);
                itemC.SubItems.Add(item.CourseTitle);
                itemC.SubItems.Add(item.TotalHour.ToString());
                listViewCourse.Items.Add(itemC);

            }
        }
    }
}
